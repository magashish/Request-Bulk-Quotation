<?php 
class Rvtech_Quotepopup_Block_Quotepopup extends Mage_Core_Block_Template
{
	public function getFormUrl()
	    {
	        $url=Mage::getBaseUrl();
	        return $url;
	    }
	
}